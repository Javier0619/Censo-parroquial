import React, { useState, useEffect } from 'react';
import { LoginForm } from './components/LoginForm';
import { CensistaDashboard } from './components/CensistaDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { CensusForm } from './components/CensusForm';
import { UserManagement } from './components/UserManagement';
import { Church } from 'lucide-react';

export interface User {
  id: string;
  name: string;
  role: 'censista' | 'admin' | 'supervisor';
  pastoral?: string;
  pin?: string;
}

export interface CensusRecord {
  id: string;
  calle: string;
  numeroCasa: string;
  nombreFamilia: string;
  telefono?: string;
  email?: string;
  numeroPersonas: number;
  solicitudesEspeciales: {
    visitaSacerdote: boolean;
    comunion: boolean;
    confesion: boolean;
    bendicionHogar: boolean;
    otros: string;
  };
  observaciones: string;
  censistaId: string;
  censistaName: string;
  fecha: string;
}

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<'login' | 'dashboard' | 'census' | 'admin' | 'users'>('login');
  const [users, setUsers] = useState<User[]>([]);
  const [censusRecords, setCensusRecords] = useState<CensusRecord[]>([]);

  useEffect(() => {
    // Load data from localStorage
    const savedUsers = localStorage.getItem('parroquial-users');
    const savedRecords = localStorage.getItem('parroquial-census');
    
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      // Initialize with default admin user
      const defaultUsers = [
        {
          id: 'USR78241XK',
          name: 'Administrador Principal',
          role: 'admin' as const,
          pin: '4397'
        }
      ];
      setUsers(defaultUsers);
      localStorage.setItem('parroquial-users', JSON.stringify(defaultUsers));
    }

    if (savedRecords) {
      setCensusRecords(JSON.parse(savedRecords));
    }
  }, []);

  useEffect(() => {
    // Save users to localStorage
    localStorage.setItem('parroquial-users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    // Save census records to localStorage
    localStorage.setItem('parroquial-census', JSON.stringify(censusRecords));
  }, [censusRecords]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setCurrentView(user.role === 'admin' ? 'admin' : 'dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('login');
  };

  const addUser = (userData: Omit<User, 'id'>) => {
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`
    };
    setUsers(prev => [...prev, newUser]);
  };

  const addCensusRecord = (record: Omit<CensusRecord, 'id' | 'fecha'>) => {
    const newRecord: CensusRecord = {
      ...record,
      id: `census-${Date.now()}`,
      fecha: new Date().toISOString()
    };
    setCensusRecords(prev => [...prev, newRecord]);
  };

  if (currentView === 'login') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Church className="h-12 w-12 text-blue-700 mr-3" />
              <h1 className="text-4xl font-bold text-gray-800">Census Parroquial</h1>
            </div>
            <p className="text-gray-600">Sistema de registro y seguimiento pastoral</p>
          </div>
          <LoginForm users={users} onLogin={handleLogin} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Church className="h-8 w-8 text-blue-700 mr-3" />
              <h1 className="text-2xl font-bold text-gray-800">Census Parroquial</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Bienvenido, <strong>{currentUser?.name}</strong>
              </span>
              <button
                onClick={handleLogout}
                className="text-sm text-blue-600 hover:text-blue-800 transition-colors"
              >
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {currentView === 'dashboard' && currentUser?.role === 'censista' && (
          <CensistaDashboard
            onStartCensus={() => setCurrentView('census')}
            censusRecords={censusRecords.filter(r => r.censistaId === currentUser.id)}
          />
        )}

        {currentView === 'census' && (
          <CensusForm
            currentUser={currentUser!}
            onSubmit={addCensusRecord}
            onBack={() => setCurrentView('dashboard')}
          />
        )}

        {currentView === 'admin' && currentUser?.role === 'admin' && (
          <AdminDashboard
            censusRecords={censusRecords}
            users={users}
            onManageUsers={() => setCurrentView('users')}
          />
        )}

        {currentView === 'users' && currentUser?.role === 'admin' && (
          <UserManagement
            users={users}
            onAddUser={addUser}
            onBack={() => setCurrentView('admin')}
          />
        )}
      </main>
    </div>
  );
}

export default App;