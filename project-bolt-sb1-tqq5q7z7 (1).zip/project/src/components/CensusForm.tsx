import React, { useState } from 'react';
import { User, CensusRecord } from '../App';
import { ArrowLeft, Save, Home, Users, Phone, Mail } from 'lucide-react';

interface CensusFormProps {
  currentUser: User;
  onSubmit: (record: Omit<CensusRecord, 'id' | 'fecha'>) => void;
  onBack: () => void;
}

export const CensusForm: React.FC<CensusFormProps> = ({
  currentUser,
  onSubmit,
  onBack
}) => {
  const [formData, setFormData] = useState({
    calle: '',
    numeroCasa: '',
    nombreFamilia: '',
    telefono: '',
    email: '',
    numeroPersonas: 1,
    solicitudesEspeciales: {
      visitaSacerdote: false,
      comunion: false,
      confesion: false,
      bendicionHogar: false,
      otros: ''
    },
    observaciones: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const record = {
      ...formData,
      censistaId: currentUser.id,
      censistaName: currentUser.name
    };

    onSubmit(record);
    
    // Reset form
    setFormData({
      calle: '',
      numeroCasa: '',
      nombreFamilia: '',
      telefono: '',
      email: '',
      numeroPersonas: 1,
      solicitudesEspeciales: {
        visitaSacerdote: false,
        comunion: false,
        confesion: false,
        bendicionHogar: false,
        otros: ''
      },
      observaciones: ''
    });

    alert('Registro guardado exitosamente');
  };

  const handleSpecialRequestChange = (key: keyof typeof formData.solicitudesEspeciales, value: boolean | string) => {
    setFormData(prev => ({
      ...prev,
      solicitudesEspeciales: {
        ...prev.solicitudesEspeciales,
        [key]: value
      }
    }));
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="flex items-center text-blue-600 hover:text-blue-800 transition-colors mr-4"
        >
          <ArrowLeft className="h-5 w-5 mr-1" />
          Volver
        </button>
        <h2 className="text-3xl font-bold text-gray-800">Nuevo Registro de Censo</h2>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-8 space-y-8">
        {/* Información de Ubicación */}
        <div className="border-b border-gray-200 pb-6">
          <div className="flex items-center mb-4">
            <Home className="h-6 w-6 text-blue-600 mr-2" />
            <h3 className="text-xl font-semibold text-gray-800">Información de Ubicación</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Calle o Dirección
              </label>
              <input
                type="text"
                required
                value={formData.calle}
                onChange={(e) => setFormData(prev => ({ ...prev, calle: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Ej: Calle Principal, Avenida Bolívar"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número de Casa
              </label>
              <input
                type="text"
                required
                value={formData.numeroCasa}
                onChange={(e) => setFormData(prev => ({ ...prev, numeroCasa: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Ej: 123, S/N, Km 5"
              />
            </div>
          </div>
        </div>

        {/* Información Familiar */}
        <div className="border-b border-gray-200 pb-6">
          <div className="flex items-center mb-4">
            <Users className="h-6 w-6 text-blue-600 mr-2" />
            <h3 className="text-xl font-semibold text-gray-800">Información Familiar</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre de la Familia o Persona Responsable
              </label>
              <input
                type="text"
                required
                value={formData.nombreFamilia}
                onChange={(e) => setFormData(prev => ({ ...prev, nombreFamilia: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Ej: Familia García, María Rodríguez"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Phone className="h-4 w-4 inline mr-1" />
                Teléfono (opcional)
              </label>
              <input
                type="tel"
                value={formData.telefono}
                onChange={(e) => setFormData(prev => ({ ...prev, telefono: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="Ej: +58 414 123 4567"
              />
            </div>
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Mail className="h-4 w-4 inline mr-1" />
              Correo Electrónico (opcional)
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              placeholder="ejemplo@correo.com"
            />
          </div>
        </div>

        {/* Solicitudes Especiales */}
        <div className="border-b border-gray-200 pb-6">
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Solicitudes Especiales</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={formData.solicitudesEspeciales.visitaSacerdote}
                  onChange={(e) => handleSpecialRequestChange('visitaSacerdote', e.target.checked)}
                  className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-gray-700">Visita del Sacerdote</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={formData.solicitudesEspeciales.comunion}
                  onChange={(e) => handleSpecialRequestChange('comunion', e.target.checked)}
                  className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-gray-700">Llevar la Comunión</span>
              </label>
            </div>
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={formData.solicitudesEspeciales.confesion}
                  onChange={(e) => handleSpecialRequestChange('confesion', e.target.checked)}
                  className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-gray-700">Confesión</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={formData.solicitudesEspeciales.bendicionHogar}
                  onChange={(e) => handleSpecialRequestChange('bendicionHogar', e.target.checked)}
                  className="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="text-gray-700">Bendición del Hogar</span>
              </label>
            </div>
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Otras Solicitudes Especiales
            </label>
            <textarea
              value={formData.solicitudesEspeciales.otros}
              onChange={(e) => handleSpecialRequestChange('otros', e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              rows={3}
              placeholder="Describe cualquier otra necesidad pastoral especial..."
            />
          </div>
        </div>

        {/* Observaciones */}
        <div>
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Observaciones Adicionales</h3>
          <textarea
            value={formData.observaciones}
            onChange={(e) => setFormData(prev => ({ ...prev, observaciones: e.target.value }))}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            rows={4}
            placeholder="Notas adicionales sobre la familia, situaciones especiales, etc..."
          />
        </div>

        {/* Submit Button */}
        <div className="pt-6">
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-4 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all"
          >
            <Save className="h-6 w-6" />
            <span>Guardar Registro</span>
          </button>
        </div>
      </form>
    </div>
  );
};