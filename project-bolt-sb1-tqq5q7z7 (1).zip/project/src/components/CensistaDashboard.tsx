import React from 'react';
import { CensusRecord } from '../App';
import { PlusCircle, Users, Calendar, MapPin } from 'lucide-react';

interface CensistaDashboardProps {
  onStartCensus: () => void;
  censusRecords: CensusRecord[];
}

export const CensistaDashboard: React.FC<CensistaDashboardProps> = ({
  onStartCensus,
  censusRecords
}) => {
  const totalFamilies = censusRecords.length;
  const totalPersons = censusRecords.reduce((sum, record) => sum + record.numeroPersonas, 0);
  const totalRequests = censusRecords.reduce((sum, record) => {
    const requests = record.solicitudesEspeciales;
    return sum + (requests.visitaSacerdote ? 1 : 0) + (requests.comunion ? 1 : 0) + 
           (requests.confesion ? 1 : 0) + (requests.bendicionHogar ? 1 : 0);
  }, 0);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Panel del Censista</h2>
        <p className="text-gray-600">Gestiona y registra la información de las familias de la parroquia</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-600">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Familias Registradas</p>
              <p className="text-2xl font-bold text-gray-800">{totalFamilies}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-600">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Personas</p>
              <p className="text-2xl font-bold text-gray-800">{totalPersons}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-600">
          <div className="flex items-center">
            <Calendar className="h-8 w-8 text-yellow-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Solicitudes Especiales</p>
              <p className="text-2xl font-bold text-gray-800">{totalRequests}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="text-center">
        <button
          onClick={onStartCensus}
          className="bg-blue-600 text-white px-8 py-4 rounded-xl hover:bg-blue-700 transition-colors flex items-center space-x-3 mx-auto text-lg font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all"
        >
          <PlusCircle className="h-6 w-6" />
          <span>Registrar Nueva Familia</span>
        </button>
      </div>

      {/* Recent Records */}
      {censusRecords.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Registros Recientes</h3>
          <div className="space-y-4">
            {censusRecords.slice(-5).reverse().map((record) => (
              <div key={record.id} className="border-l-4 border-blue-200 pl-4 py-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-800">{record.nombreFamilia}</h4>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{record.calle} #{record.numeroCasa}</span>
                      <span className="mx-2">•</span>
                      <span>{record.numeroPersonas} personas</span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500">
                    {new Date(record.fecha).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};