import React, { useState } from 'react';
import { User } from '../App';
import { LogIn, UserCircle, Shield } from 'lucide-react';

interface LoginFormProps {
  users: User[];
  onLogin: (user: User) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ users, onLogin }) => {
  const [loginType, setLoginType] = useState<'censista' | 'admin'>('censista');
  const [formData, setFormData] = useState({
    name: '',
    pastoral: '',
    userId: '',
    pin: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (loginType === 'censista') {
      // Create or find censista user
      const existingUser = users.find(u => u.name === formData.name && u.role === 'censista');
      if (existingUser) {
        onLogin(existingUser);
      } else {
        const newUser: User = {
          id: `censista-${Date.now()}`,
          name: formData.name,
          role: 'censista',
          pastoral: formData.pastoral
        };
        onLogin(newUser);
      }
    } else {
      // Admin login
      const adminUser = users.find(u => u.id === formData.userId && u.pin === formData.pin);
      if (adminUser) {
        onLogin(adminUser);
      } else {
        alert('ID de usuario o PIN incorrecto');
      }
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex mb-6">
          <button
            onClick={() => setLoginType('censista')}
            className={`flex-1 py-3 px-4 rounded-l-lg border-2 transition-all ${
              loginType === 'censista'
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
            }`}
          >
            <UserCircle className="h-5 w-5 mx-auto mb-1" />
            <span className="text-sm font-medium">Censista</span>
          </button>
          <button
            onClick={() => setLoginType('admin')}
            className={`flex-1 py-3 px-4 rounded-r-lg border-2 transition-all ${
              loginType === 'admin'
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
            }`}
          >
            <Shield className="h-5 w-5 mx-auto mb-1" />
            <span className="text-sm font-medium">Administrador</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {loginType === 'censista' ? (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Tu nombre completo"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pastoral o Grupo
                </label>
                <input
                  type="text"
                  required
                  value={formData.pastoral}
                  onChange={(e) => setFormData(prev => ({ ...prev, pastoral: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Escribe tu pastoral o grupo"
                />
              </div>
            </>
          ) : (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ID de Usuario
                </label>
                <input
                  type="text"
                  required
                  value={formData.userId}
                  onChange={(e) => setFormData(prev => ({ ...prev, userId: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Ingresa tu ID de usuario"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  PIN
                </label>
                <input
                  type="password"
                  required
                  value={formData.pin}
                  onChange={(e) => setFormData(prev => ({ ...prev, pin: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="••••"
                />
              </div>
            </>
          )}

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 font-medium"
          >
            <LogIn className="h-5 w-5" />
            <span>Ingresar</span>
          </button>
        </form>
      </div>
    </div>
  );
};