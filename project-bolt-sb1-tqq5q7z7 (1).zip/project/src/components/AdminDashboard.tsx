import React, { useState } from 'react';
import { CensusRecord, User } from '../App';
import { Users, MapPin, Calendar, Search, Filter, Settings, Eye, Phone, Mail } from 'lucide-react';

interface AdminDashboardProps {
  censusRecords: CensusRecord[];
  users: User[];
  onManageUsers: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  censusRecords,
  users,
  onManageUsers
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBy, setFilterBy] = useState<'all' | 'recent' | 'requests'>('all');
  const [selectedRecord, setSelectedRecord] = useState<CensusRecord | null>(null);

  const totalFamilies = censusRecords.length;
  const totalPersons = censusRecords.reduce((sum, record) => sum + record.numeroPersonas, 0);
  const totalCensistas = users.filter(u => u.role === 'censista').length;
  const totalRequests = censusRecords.reduce((sum, record) => {
    const requests = record.solicitudesEspeciales;
    return sum + (requests.visitaSacerdote ? 1 : 0) + (requests.comunion ? 1 : 0) + 
           (requests.confesion ? 1 : 0) + (requests.bendicionHogar ? 1 : 0);
  }, 0);

  const filteredRecords = censusRecords.filter(record => {
    const matchesSearch = record.nombreFamilia.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.calle.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.censistaName.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filterBy === 'recent') {
      const recordDate = new Date(record.fecha);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return matchesSearch && recordDate >= weekAgo;
    }
    
    if (filterBy === 'requests') {
      const hasRequests = record.solicitudesEspeciales.visitaSacerdote ||
                         record.solicitudesEspeciales.comunion ||
                         record.solicitudesEspeciales.confesion ||
                         record.solicitudesEspeciales.bendicionHogar ||
                         record.solicitudesEspeciales.otros;
      return matchesSearch && hasRequests;
    }
    
    return matchesSearch;
  });

  const getSpecialRequests = (record: CensusRecord) => {
    const requests = [];
    if (record.solicitudesEspeciales.visitaSacerdote) requests.push('Visita del Sacerdote');
    if (record.solicitudesEspeciales.comunion) requests.push('Comunión');
    if (record.solicitudesEspeciales.confesion) requests.push('Confesión');
    if (record.solicitudesEspeciales.bendicionHogar) requests.push('Bendición del Hogar');
    if (record.solicitudesEspeciales.otros) requests.push(record.solicitudesEspeciales.otros);
    return requests;
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Panel Administrativo</h2>
          <p className="text-gray-600">Monitoreo en tiempo real del censo parroquial</p>
        </div>
        <button
          onClick={onManageUsers}
          className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
        >
          <Settings className="h-5 w-5" />
          <span>Gestionar Usuarios</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-600">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-blue-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Familias</p>
              <p className="text-2xl font-bold text-gray-800">{totalFamilies}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-600">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-green-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total Personas</p>
              <p className="text-2xl font-bold text-gray-800">{totalPersons}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-600">
          <div className="flex items-center">
            <Calendar className="h-8 w-8 text-yellow-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Solicitudes Especiales</p>
              <p className="text-2xl font-bold text-gray-800">{totalRequests}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-purple-600">
          <div className="flex items-center">
            <Users className="h-8 w-8 text-purple-600" />
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Censistas Activos</p>
              <p className="text-2xl font-bold text-gray-800">{totalCensistas}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar familias, calles o censistas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all w-80"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value as typeof filterBy)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              >
                <option value="all">Todos los registros</option>
                <option value="recent">Registros recientes (7 días)</option>
                <option value="requests">Con solicitudes especiales</option>
              </select>
            </div>
          </div>
          <div className="text-sm text-gray-600">
            Mostrando {filteredRecords.length} de {totalFamilies} registros
          </div>
        </div>
      </div>

      {/* Records Table */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Familia
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ubicación
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Personas
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Censista
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Fecha
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRecords.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{record.nombreFamilia}</div>
                    {record.telefono && (
                      <div className="text-sm text-gray-500 flex items-center mt-1">
                        <Phone className="h-3 w-3 mr-1" />
                        {record.telefono}
                      </div>
                    )}
                    {record.email && (
                      <div className="text-sm text-gray-500 flex items-center mt-1">
                        <Mail className="h-3 w-3 mr-1" />
                        {record.email}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-sm text-gray-900">
                      <MapPin className="h-4 w-4 mr-1 text-gray-400" />
                      {record.calle} #{record.numeroCasa}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {record.numeroPersonas}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {record.censistaName}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(record.fecha).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => setSelectedRecord(record)}
                      className="text-blue-600 hover:text-blue-900 flex items-center"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Ver
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Detail Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-800">Detalle del Registro</h3>
                <button
                  onClick={() => setSelectedRecord(null)}
                  className="text-gray-400 hover:text-gray-600 text-2xl"
                >
                  ×
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold text-gray-800 mb-2">Información Básica</h4>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    <p><strong>Familia:</strong> {selectedRecord.nombreFamilia}</p>
                    <p><strong>Dirección:</strong> {selectedRecord.calle} #{selectedRecord.numeroCasa}</p>
                    <p><strong>Número de Personas:</strong> {selectedRecord.numeroPersonas}</p>
                    {selectedRecord.telefono && <p><strong>Teléfono:</strong> {selectedRecord.telefono}</p>}
                    {selectedRecord.email && <p><strong>Email:</strong> {selectedRecord.email}</p>}
                    <p><strong>Censista:</strong> {selectedRecord.censistaName}</p>
                    <p><strong>Fecha:</strong> {new Date(selectedRecord.fecha).toLocaleString()}</p>
                  </div>
                </div>

                {getSpecialRequests(selectedRecord).length > 0 && (
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-2">Solicitudes Especiales</h4>
                    <div className="bg-yellow-50 rounded-lg p-4">
                      <ul className="list-disc list-inside space-y-1">
                        {getSpecialRequests(selectedRecord).map((request, index) => (
                          <li key={index} className="text-yellow-800">{request}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}

                {selectedRecord.observaciones && (
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-2">Observaciones</h4>
                    <div className="bg-blue-50 rounded-lg p-4">
                      <p className="text-blue-800">{selectedRecord.observaciones}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};